import React from 'react';
import './FlowerAnimation.css';

const FlowerAnimation: React.FC = () => {
  return (
    <div className="flower-animation-container">
      <div className="flower flower-1">🌸</div>
      <div className="flower flower-2">🌺</div>
      <div className="flower flower-3">🌼</div>
      <div className="flower flower-4">🌸</div>
      <div className="flower flower-5">🌺</div>
      <div className="flower flower-6">🌼</div>
    </div>
  );
};

export default FlowerAnimation;
