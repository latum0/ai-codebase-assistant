import React from 'react';
import './CelebrationPage.css';
import usPng from '../../assets/us.png';

interface CelebrationPageProps {
  name: string;
}

const CelebrationPage: React.FC<CelebrationPageProps> = () => {
  return (
    <div className="celebration-container">
      <div className="background-animation">
        <div className="animated-bg-1"></div>
        <div className="animated-bg-2"></div>
        <div className="animated-bg-3"></div>
      </div>

      {/* Floating balloons */}
      <div className="balloon balloon-1">🎈</div>
      <div className="balloon balloon-2">🎉</div>
      <div className="balloon balloon-3">🎊</div>
      <div className="balloon balloon-4">🎁</div>
      <div className="balloon balloon-5">💚</div>

      {/* Main content */}
      <div className="celebration-content">
        <div className="content-wrapper">
          <h1 className="celebration-title">
            To the <span className="highlight">best woman ever</span>
          </h1>

          <p
            style={{
              textAlign: 'center',
              fontSize: '1.1em',
              color: '#555',
              lineHeight: '1.8',
              marginBottom: '40px',
              maxWidth: '600px',
              margin: '0 auto 40px auto',
            }}
          >
            bon i know i am not the best at talking (i am shit), i don't wanna
            make this shittier so i'll make it short. you are literally the best
            thing that came into my life, and i know u gonna think i am
            exaggerating but wlh i am not, my life got better x100 just because
            of YOU, you make my days better, you make me happy so easilyyyy, so
            i wanna make you the happiest woman alive (it sounds like a
            proposal, that's why i suck), anyways, happy birthday a ziniw, i
            hope we can celebrate your 100th birthday together insha'allah.
          </p>

          <div
            style={{
              width: '100%',
              maxWidth: '500px',
              margin: '0 auto',
              marginBottom: '40px',
            }}
          >
            <img
              src={usPng}
              alt="Us"
              style={{
                width: '100%',
                borderRadius: '15px',
                boxShadow: '0 10px 30px rgba(0,0,0,0.2)',
              }}
            />
          </div>

          <div className="celebration-message">
            <p>I LOVE YOU SOOOOOOOO MUCH 💚💚💚</p>
          </div>

          {/* Particle effect */}
          <div className="particles">
            {Array.from({ length: 20 }).map((_, i) => (
              <div
                key={i}
                className="particle"
                style={
                  {
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                    animationDelay: `${Math.random() * 2}s`,
                  } as React.CSSProperties
                }
              ></div>
            ))}
          </div>
        </div>
      </div>

      {/* Floating hearts background */}
      <div className="floating-hearts">
        {Array.from({ length: 15 }).map((_, i) => (
          <div
            key={i}
            className="heart"
            style={
              {
                left: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
              } as React.CSSProperties
            }
          >
            💚
          </div>
        ))}
      </div>
    </div>
  );
};

export default CelebrationPage;
