import React, { useState } from 'react';
import './PhotosModal.css';
import FlowerAnimation from '../components/FlowerAnimation/FlowerAnimation';

interface PhotosModalProps {
  name: string;
  onConfirm: () => void;
  onCancel: () => void;
}

const PhotosModal: React.FC<PhotosModalProps> = ({
  name,
  onConfirm,
  onCancel,
}) => {
  const [isClosing, setIsClosing] = useState(false);

  const handleButtonClick = (action: 'confirm' | 'cancel') => {
    setIsClosing(true);
    setTimeout(() => {
      if (action === 'confirm') {
        onConfirm();
      } else {
        onCancel();
      }
    }, 300);
  };

  return (
    <div className={`photos-modal-overlay ${isClosing ? 'closing' : ''}`}>
      <FlowerAnimation />
      <div
        className={`photos-modal-content ${isClosing ? 'modal-close' : 'modal-open'}`}
      >
        {/* Confetti elements */}
        <div className="confetti confetti-1"></div>
        <div className="confetti confetti-2"></div>
        <div className="confetti confetti-3"></div>

        <div className="photos-modal-header">
          <h1 className="photos-title">Memories of {name} 📸</h1>
        </div>

        <div className="photos-container">
          <div className="photo-placeholder">
            <span className="photo-icon">🎥</span>
            <p>Add your favorite photos or GIFs here!</p>
          </div>
        </div>

        <div className="photos-button-container">
          <button
            className="btn btn-primary"
            onClick={() => handleButtonClick('confirm')}
          >
            Let's Celebrate 🎉
          </button>
          <button
            className="btn btn-secondary"
            onClick={() => handleButtonClick('cancel')}
          >
            Back
          </button>
        </div>

        {/* Decorative shapes */}
        <div className="decoration decoration-1"></div>
        <div className="decoration decoration-2"></div>
      </div>
    </div>
  );
};

export default PhotosModal;
