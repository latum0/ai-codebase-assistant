import React, { useState } from 'react';
import './PhotosModal1.css';
import FlowerAnimation from '../FlowerAnimation/FlowerAnimation';
import midJpg from '../../assets/mid.jpg';

interface PhotosModal1Props {
  name: string;
  onConfirm: () => void;
  onCancel: () => void;
}

const PhotosModal1: React.FC<PhotosModal1Props> = ({ onConfirm, onCancel }) => {
  const [isClosing, setIsClosing] = useState(false);

  const handleButtonClick = (action: 'confirm' | 'cancel') => {
    setIsClosing(true);
    setTimeout(() => {
      if (action === 'confirm') {
        onConfirm();
      } else {
        onCancel();
      }
    }, 300);
  };

  return (
    <div className={`photos-modal-overlay ${isClosing ? 'closing' : ''}`}>
      <FlowerAnimation />
      <div
        className={`photos-modal-content ${isClosing ? 'modal-close' : 'modal-open'}`}
      >
        {/* Confetti elements */}
        <div className="confetti confetti-1"></div>
        <div className="confetti confetti-2"></div>
        <div className="confetti confetti-3"></div>

        <div className="photos-modal-header">
          <h1 className="photos-title">A hater yebqa hater 😔</h1>
        </div>

        <div>
          <img
            src={midJpg}
            alt="Memory"
            style={{ width: '100%', borderRadius: '15px' }}
          />
        </div>

        <div className="photos-button-container">
          <button
            className="btn btn-primary"
            onClick={() => handleButtonClick('confirm')}
          >
            Thank you 💚
          </button>
          <button
            className="btn btn-secondary"
            onClick={() => handleButtonClick('cancel')}
          >
            thank you bro
          </button>
        </div>

        {/* Decorative shapes */}
        <div className="decoration decoration-1"></div>
        <div className="decoration decoration-2"></div>
      </div>
    </div>
  );
};

export default PhotosModal1;
