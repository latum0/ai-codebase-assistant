import React, { useState } from 'react';
import './BirthdayModal.css';
import FlowerAnimation from '../FlowerAnimation/FlowerAnimation';

interface BirthdayModalProps {
  name: string;
  onConfirm: () => void;
  onCancel: () => void;
}

const BirthdayModal: React.FC<BirthdayModalProps> = ({
  name,
  onConfirm,
  onCancel,
}) => {
  const [isClosing, setIsClosing] = useState(false);

  const handleButtonClick = (action: 'thanks' | 'cancel') => {
    setIsClosing(true);
    setTimeout(() => {
      if (action === 'thanks') {
        onConfirm();
      } else {
        onCancel();
      }
    }, 300);
  };

  return (
    <div className={`modal-overlay ${isClosing ? 'closing' : ''}`}>
      <FlowerAnimation />
      <div
        className={`modal-content ${isClosing ? 'modal-close' : 'modal-open'}`}
      >
        <div className="confetti confetti-1"></div>
        <div className="confetti confetti-2"></div>
        <div className="confetti confetti-3"></div>
        <div className="confetti confetti-4"></div>
        <div className="confetti confetti-5"></div>

        <div className="modal-header">
          <h1 className="birthday-title">Happy Birthday my {name}💚</h1>
        </div>

        <p className="modal-subtitle">
          La3qouba l 100ans nchlh 💚 (ofc only if we are together, sinon die
          asap)
        </p>

        <div className="button-container">
          <button
            className="btn btn-thanks"
            onClick={() => handleButtonClick('thanks')}
          >
            Thank you 💚
          </button>
          <button
            className="btn btn-cancel"
            onClick={() => handleButtonClick('cancel')}
          >
            No, i hate you
          </button>
        </div>
        <div className="decoration decoration-1"></div>
        <div className="decoration decoration-2"></div>
        <div className="decoration decoration-3"></div>
      </div>
    </div>
  );
};

export default BirthdayModal;
