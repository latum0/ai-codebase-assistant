import React, { useLayoutEffect, useRef, useState } from 'react';
import './PhotosModal3.css';
import FlowerAnimation from '../FlowerAnimation/FlowerAnimation';
import slapGif from '../../assets/slap.gif';

interface PhotosModal3Props {
  name: string;
  onConfirm: () => void;
}

const PhotosModal3: React.FC<PhotosModal3Props> = ({ onConfirm }) => {
  const [isClosing, setIsClosing] = useState(false);
  const [cancelButtonPos, setCancelButtonPos] = useState({ x: 0, y: 0 });
  const [escapeCount, setEscapeCount] = useState(0);

  const confirmButtonRef = useRef<HTMLButtonElement>(null);
  const cancelButtonRef = useRef<HTMLButtonElement>(null);

  const handleConfirmClick = () => {
    setIsClosing(true);
    setTimeout(() => {
      onConfirm();
    }, 300);
  };

  const clamp = (value: number, min: number, max: number) =>
    Math.min(Math.max(value, min), max);

  const moveButtonAway = () => {
    const button = cancelButtonRef.current;
    if (!button) return;

    const rect = button.getBoundingClientRect();
    const margin = 12;

    const maxX = Math.max(margin, window.innerWidth - rect.width - margin);
    const maxY = Math.max(margin, window.innerHeight - rect.height - margin);

    const randomX = margin + Math.random() * (maxX - margin);
    const randomY = margin + Math.random() * (maxY - margin);

    setCancelButtonPos({ x: randomX, y: randomY });
    setEscapeCount((prev) => prev + 1);
  };

  const handleCancelHover = () => {
    moveButtonAway();
  };

  const handleCancelMouseMove = () => {
    moveButtonAway();
  };

  const handleCancelClick = (e: React.MouseEvent) => {
    e.preventDefault();
    moveButtonAway();
  };

  useLayoutEffect(() => {
    const confirmButton = confirmButtonRef.current;
    const cancelButton = cancelButtonRef.current;

    if (!confirmButton || !cancelButton) return;

    const confirmRect = confirmButton.getBoundingClientRect();
    const cancelRect = cancelButton.getBoundingClientRect();
    const margin = 12;

    const desiredX = confirmRect.right + margin;
    const desiredY = confirmRect.top;

    const safeX = clamp(
      desiredX,
      margin,
      window.innerWidth - cancelRect.width - margin,
    );
    const safeY = clamp(
      desiredY,
      margin,
      window.innerHeight - cancelRect.height - margin,
    );

    setCancelButtonPos({ x: safeX, y: safeY });
  }, []);

  return (
    <div className={`photos-modal-overlay ${isClosing ? 'closing' : ''}`}>
      <FlowerAnimation />
      <style>{`
        .btn-escape {
          position: fixed !important;
          transition: left 0.2s ease, top 0.2s ease;
          pointer-events: auto;
          z-index: 1001;
        }

        .btn-escape:hover {
          transform: none !important;
        }

        @media (max-width: 600px) {
          .btn-escape {
            position: fixed !important;
          }
        }
      `}</style>

      <div
        className={`photos-modal-content ${isClosing ? 'modal-close' : 'modal-open'}`}
      >
        <div className="confetti confetti-1"></div>
        <div className="confetti confetti-2"></div>
        <div className="confetti confetti-3"></div>

        <div className="photos-modal-header">
          <h1 className="photos-title">
            Aya ichatam ataghyoult, and i am not your bro
          </h1>
        </div>

        <div className="photos-container">
          <img
            src={slapGif}
            alt="Memory"
            style={{ width: '100%', borderRadius: '15px' }}
          />
        </div>

        {escapeCount > 0 && (
          <div className="playful-message">
            <p>
              {escapeCount === 1 && ''}
              {escapeCount === 2 && ''}
              {escapeCount === 3 && ''}
              {escapeCount >= 4 && 'just click on the other button ya rebb'}
            </p>
          </div>
        )}

        <div className="photos-button-container">
          <button
            ref={confirmButtonRef}
            className="btn btn-primary"
            onClick={handleConfirmClick}
          >
            Thank you 💚
          </button>
        </div>

        <button
          ref={cancelButtonRef}
          className="btn btn-secondary btn-escape"
          onMouseEnter={handleCancelHover}
          onMouseMove={handleCancelMouseMove}
          onMouseDown={handleCancelClick}
          onTouchStart={handleCancelHover}
          style={{
            left: `${cancelButtonPos.x}px`,
            top: `${cancelButtonPos.y}px`,
          }}
        >
          idc
        </button>

        <div className="decoration decoration-1"></div>
        <div className="decoration decoration-2"></div>
      </div>
    </div>
  );
};

export default PhotosModal3;
