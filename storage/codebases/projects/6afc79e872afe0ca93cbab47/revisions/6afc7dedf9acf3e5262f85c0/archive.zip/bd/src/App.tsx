import { useState } from 'react';
import './App.css';
import BirthdayModal from './components/BirthdayModal/BirthdayModal';
import PhotosModal1 from './components/PhotosModal1/PhotosModal1';
import PhotosModal3 from './components/PhotosModal3/PhotosModal3';
import CelebrationPage from './components/CelebrationPage/CelebrationPage';

type View = 'birthday' | 'photos1' | 'photos3' | 'celebration';

function App() {
  const [currentView, setCurrentView] = useState<View>('birthday');
  const [name] = useState('Iméne');

  const handleBirthdayConfirm = () => {
    setCurrentView('celebration');
  };

  const handleBirthdayCancel = () => {
    setCurrentView('photos1');
  };

  const handlePhotos1Confirm = () => {
    setCurrentView('celebration');
  };

  const handlePhotos1Cancel = () => {
    setCurrentView('photos3');
  };

  const handlePhotos3Confirm = () => {
    setCurrentView('celebration');
  };

  return (
    <div className="app">
      {currentView === 'birthday' && (
        <BirthdayModal
          name={name}
          onConfirm={handleBirthdayConfirm}
          onCancel={handleBirthdayCancel}
        />
      )}
      {currentView === 'photos1' && (
        <PhotosModal1
          name={name}
          onConfirm={handlePhotos1Confirm}
          onCancel={handlePhotos1Cancel}
        />
      )}
      {currentView === 'photos3' && (
        <PhotosModal3 name={name} onConfirm={handlePhotos3Confirm} />
      )}
      {currentView === 'celebration' && <CelebrationPage name={name} />}
    </div>
  );
}

export default App;
